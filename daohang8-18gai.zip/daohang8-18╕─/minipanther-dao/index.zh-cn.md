---
title: "MiniPanther DAO"
description: "MiniPanther 是一个 DAO，有 14 天的供应扩张，然后在第 15 天进行 80% 的国债回购。在那之后，MP 成为 Fantom 网络的 meme 代币！"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["seven"]
featuredImage: "minipanther-dao.png"
tags: ["DeFi","MiniPanther DAO"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Fantom"
website: "https://minipanther.money/?utm_source=DappRadar&utm_medium=deeplink&utm_campaign=visit-website#/"
twitter: "https://twitter.com/PolyWantsAFarm"
discord: "https://discord.com/invite/YwZ9qw62cH"
telegram: "https://t.me/PolyWantsACracker_Farm"
github: "https://github.com/LithiumSwapTech/minipanther-contracts"
youtube: "https://www.youtube.com/channel/UCv1i6qmR7SFKXBFDKbrJWzg"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://polywantsacrackerfarm.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
MiniPanther 是一个只允许供应扩展 14 天的 DAO。在第 15 天，除 MP-DAI LP 外，80% 的资金将用于回购。回购由自定义功能控制 - 管理员没有资金提取能力。回购完成后，MP 将成为 Fantom Network 的 meme 代币。双重质押产生 MP rebase 奖励 + Dark Knight 奖励奖励。黑猫相关的慈善捐赠。

![1](1660894495649.jpg)

![2](1660894515668.jpg)