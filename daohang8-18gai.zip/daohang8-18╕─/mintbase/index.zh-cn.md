---
title: "Mintbase"
description: "在您自己的智能合约上铸造、出售、交易 NFT"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["seven"]
featuredImage: "mintbase.png"
tags: ["Marketplaces","Mintbase"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "NEAR"
website: "https://www.mintbase.io/?utm_source=DappRadar&utm_medium=deeplink&utm_campaign=visit-website"
twitter: "https://twitter.com/mintbase"
discord: "https://discord.com/invite/fdsDnS57"
telegram: "https://t.me/mintbase"
github: "https://github.com/mintbase"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/mintbase"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
NFT 基础设施
对于 Web2030
在 NEAR 上使用我们的 nocode 合约管理器和开发人员工具包构建您自己的铸币厂、市场和赎回者：一个分片、可组合、快速、廉价和绿色的区块链。

开发人员可以使用像 rust 这样不断发展的喜爱语言在单事件总线分片链上部署智能合约（每个人都不必像 Optimism 那样在同一个分片上聚会）。

![1](1660895655666.jpg)

![2](1660895669130.jpg)