---
title: "Minotaur Money"
description: "Cronos 网络上的去中心化储备货币和 VC"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["seven"]
featuredImage: "minotaur-money.png"
tags: ["DeFi","Minotaur Money"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Cronos"
website: ""
twitter: "https://twitter.com/Minotaur_Money"
discord: "https://discord.com/invite/cQSNDEFC3T"
telegram: "https://t.me/MinotaurMoney"
github: "https://github.com/MinotaurMoney/"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Minotaur.Money 是 Cronos 网络上的一种储备货币和去中心化 VC，它采用交易税重新分配给利益相关者作为持有激励！

其储备货币资产MINO由财政部的一揽子混合资产（例如 CRO、WBTC、WETH、DAI）支持，并部署财政部资产为 DAO 赚取利润。

该协议采用Fractionality使国库资金能够用于去中心化 VC、跨链流动性农业或激励性投票以获得流动性奖励。

Minotaur.Money 协议采用质押和铸造（又名绑定）的动态在 Cronos 生态系统中创建以加密货币计价的储备货币。

![1](1660895401484.jpg)

![2](1660895417625.jpg)